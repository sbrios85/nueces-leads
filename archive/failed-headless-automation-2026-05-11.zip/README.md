# Failed Headless Automation Archive
**Archived**: 2026-05-11

## What's in here

Code from an attempt to automate foreclosure PDF download from the
Nueces County Clerk portal (BIS/Neumo platform).

- `scraper/pdf_reader.py` — Playwright-based login, navigation, cart-flow
  download, PDF text extraction, regex parsing of foreclosure fields,
  NCAD cross-reference for legal-description-only PDFs
- `scraper/extract_foreclosure_pdfs.py` — workflow runner that
  invoked the PDF reader
- `.github/workflows/extract_foreclosure_pdfs_morning.yml` — 9 AM CT cron
- `.github/workflows/extract_foreclosure_pdfs_evening.yml` — 4 PM CT cron

## Why archived

The portal (BIS Consultants / Neumo) detects headless Chrome and silently
refuses to fire the data-loading XHR. We could:
1. Login successfully (auth works)
2. Navigate to search-results pages (page renders shell HTML)
3. NOT extract document IDs (workspace `isLoading: true` indefinitely)
4. NOT click into doc detail pages (the click handler relied on the
   workspace data being populated, which never happens)

After 8 iterations of anti-detection patches, the headless XHR fingerprint
check could not be bypassed. See git log for the iteration history.

## Reusable pieces

If revisiting, KEEP these functions from `pdf_reader.py`:

- `parse_foreclosure_pdf_text()` — regex extraction of borrower/lender/
  loan amount/property address/legal description. Tested working, ready to
  use on any source of PDFs.
- `normalize_legal_for_match()` and `legal_descriptions_match()` —
  cross-reference legal descriptions between PDF and NCAD with token
  matching, number-word normalization, stop-word filtering
- `cross_reference_legal_descriptions()` — NCAD reverse-lookup-by-name
  for filling in property addresses when only legal description known

## What to retry if revisiting

If you want to attempt automation again:

1. Try **non-headless** local Playwright (visible Chrome on your computer):
   per the GitHub research, scrapers for this same portal family have
   succeeded with visible browsers. The bexar.tx.publicsearch.us
   community scraper uses Selenium non-headless.

2. Try a **paid stealth service** (ScrapingBee, Browserless, Bright Data):
   ~$50-100/month. They run real Chrome with anti-detection that's
   maintained by professionals.

3. Try a **browser extension** instead — runs inside your real Chrome
   session, no detection issues at all. Trade-off: requires manual click.

The PDF parsing logic is solid and worth preserving — only the
acquisition layer needs replacement.

## Cost of revisiting

About a week of work for the local-Playwright approach. Less if you keep
the parsing functions from this archive.
